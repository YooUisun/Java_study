import java.sql.*;

public class WeatherApiService {

    public void saveWeatherData(List<WeatherData> weatherDataList) {
        String dbURL = "jdbc:oracle:thin:@localhost:1521:orcl";
        String dbUser = "scott";
        String dbPassword = "tiger";
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            // DB 연결
            conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            
            String sql = "INSERT INTO weather_data (baseDate, baseTime, category, obsrValue, nx, ny, categoryCode, publishDate, publishTime, resultCode, resultMsg, totalCount, numOfRows, pageNo, dataType) "
                     + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            stmt = conn.prepareStatement(sql);
            
            // 배치로 데이터 삽입
            for (WeatherData weatherData : weatherDataList) {
                stmt.setString(1, weatherData.getBaseDate());
                stmt.setString(2, weatherData.getBaseTime());
                stmt.setString(3, weatherData.getCategory());
                stmt.setString(4, weatherData.getObsrValue());
                stmt.setInt(5, weatherData.getNx());
                stmt.setInt(6, weatherData.getNy());
                stmt.setString(7, weatherData.getCategoryCode());
                stmt.setString(8, weatherData.getPublishDate());
                stmt.setString(9, weatherData.getPublishTime());
                stmt.setString(10, weatherData.getResultCode());
                stmt.setString(11, weatherData.getResultMsg());
                stmt.setInt(12, weatherData.getTotalCount());
                stmt.setInt(13, weatherData.getNumOfRows());
                stmt.setInt(14, weatherData.getPageNo());
                stmt.setString(15, weatherData.getDataType());

                stmt.addBatch();
            }

            // 배치 실행
            stmt.executeBatch();
            System.out.println("Data successfully inserted into the database.");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

package study.Test.Test5;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // WeatherApiService와 WeatherDataRepository 객체 생성
        WeatherApiService apiService = new WeatherApiService();
        WeatherDataRepository repository = new WeatherDataRepository();

        try {
            // 예시로 여러 날짜, 시간을 요청하도록 수정
            String[] dates = {"2025-01-06", "2025-01-07"};
            String[] times = {"0600", "1200"};
            
            for (String baseDate : dates) {
                for (String baseTime : times) {
                    // API 호출
                    String jsonData = apiService.getWeatherData(baseDate, baseTime);
                    System.out.println("JSON Data for " + baseDate + " " + baseTime + ": " + jsonData);

                    if (jsonData == null || jsonData.isEmpty()) {
                        System.out.println("No data received from API");
                        continue;
                    }

                    // JSON 파싱
                    List<WeatherData> weatherDataList = apiService.parseWeatherData(jsonData);

                    if (weatherDataList.isEmpty()) {
                        System.out.println("No weather data available after parsing.");
                        continue;
                    }

                    // 결과 출력 (선택사항)
                    for (WeatherData data : weatherDataList) {
                        System.out.println(data); // 데이터 객체의 toString() 메서드가 호출되어 전체 데이터 출력
                        System.out.println("--------------------------------");
                    }

                    // DB에 저장
                    repository.saveWeatherData(weatherDataList);
                }
            }

        } catch (Exception e) {
            System.out.println("Error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

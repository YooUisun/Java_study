package study.Test.Test5;

import java.util.List;

public class WeatherDataRepository {

    // DB에 데이터를 저장하는 메서드
    public void saveWeatherData(List<WeatherData> weatherDataList) {
        for (WeatherData data : weatherDataList) {
            System.out.println("Saving weather data: " + data);
            // 여기에 실제 DB 저장 코드 구현
        }
    }
}
